# Run Evolution Lab V6 — Physiological Engine

Esta versão inclui o motor fisiológico de campo e a infraestrutura de produção.

## Motor
- validação de estágios
- conversão pace ↔ velocidade
- suavização local da curva de lactato
- basal individual
- LT1 por subida sustentada de lactato (+0,5 mmol/L) com referência ~2 mmol/L
- LT2 pelo método Dmax
- ponto de referência de 4 mmol/L reportado separadamente
- FC, pace, velocidade e lactato em LT1/LT2
- curva completa guardada no teste
- estimativa de VO₂max de campo explicitamente marcada como estimativa
- nível de confiança e método gravados com cada resultado
- histórico de testes por atleta

## Limitações científicas importantes
LT1/LT2 não têm uma definição universal única. O algoritmo deve ser configurável conforme o protocolo (estágios, duração, recuperação, equipamento e local de colheita). O método Dmax é uma abordagem de campo/laboratório, não uma verdade fisiológica absoluta.

VO₂max não deve ser chamado de medição real sem análise de gases. O valor atual é uma estimativa baseada na velocidade máxima e deve ser apresentado como tal.

VLaMax NÃO é calculável de forma fiável apenas com lactato de um teste incremental. Para VLaMax será necessário um protocolo específico de produção de lactato/anaeróbio e dados adequados.

Antes de utilização profissional, comparar o algoritmo com avaliações laboratoriais e definir o protocolo padrão da aplicação.
